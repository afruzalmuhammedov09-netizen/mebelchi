UMID MEBEL SAYT NAMUNASI
1) GitHub repositoriy oching (PUBLIC).
2) index.html va .nojekyll fayllarini repositoriy asosiy (root) joyiga yuklang.
3) Settings > Pages > Build and deployment > Deploy from a branch > main / (root) > Save.
4) Settings > Pages > Visit site orqali HTTPS manzilni oling.
5) Mijozga faqat HTTPS sahifa manzilini yuboring, ChatGPT fayl havolasini emas.

Eslatma: Narxlar va rasmlar NAMUNAVIY, do‘konning o‘z mahsulotlari deb ko‘rsatmaslik kerak. Telefon raqami hali ulanmagan.
